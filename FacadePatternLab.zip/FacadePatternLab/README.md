# Facade Pattern Lab - Flight Booking System

CSS 217 Java practical exercise. Demonstrates the **Facade Design Pattern** with five airline booking subsystems.

## Files
- `src/SeatInventorySystem.java` - seat connection, validation, locking, rollback
- `src/BaggagePricingEngine.java` - baggage surcharges
- `src/CurrencyConverter.java` - USD conversion
- `src/PaymentProcessor.java` - payment and SILVER promotion
- `src/TicketIssuer.java` - electronic ticket
- `src/FlightBookingFacade.java` - single entry point for booking
- `src/Main.java` - four test scenarios

## Run
From the project root, with JDK installed:

```bash
javac -d out src/*.java
java -cp out Main
```

On Windows Command Prompt:

```cmd
javac -d out src\*.java
java -cp out Main
```

## Tests
1. Valid booking issues an `ETKT-` code.
2. Row 13 booking returns `BOOKING_FAILED`.
3. Invalid card returns `BOOKING_FAILED` and releases the seat lock.
4. SILVER booking skips the baggage engine and applies a 10% discount.

## Architecture
`Main -> FlightBookingFacade -> five subsystem classes`

The original five subsystem classes are reproduced from the assignment PDF without intentional changes to their behavior. Only the Facade and client implement the lab logic.
