public class Main {
    public static void main(String[] args) {
        FlightBookingFacade facade = new FlightBookingFacade();

        System.out.println("=== TEST 1: Successful Booking ===");
        System.out.println("Result 1: " + facade.bookFlight(
                "Amina Suleimenova", "KC101", "14A", 320.00,
                2, 23.0, "EUR", "4532015112830366") + "\n");

        System.out.println("=== TEST 2: Blocked Seat ===");
        System.out.println("Result 2: " + facade.bookFlight(
                "Daniyar Kassymov", "KC101", "13C", 320.00,
                1, 15.0, "USD", "4532015112830366") + "\n");

        System.out.println("=== TEST 3: Payment Failure and Rollback ===");
        System.out.println("Result 3: " + facade.bookFlight(
                "Timur Bekov", "KC101", "07D", 320.00,
                1, 18.0, "KZT", "9999") + "\n");

        System.out.println("=== TEST 4: SILVER Loyalty Tier ===");
        System.out.println("Result 4: " + facade.bookFlight(
                "Aigerim Nurlanova", "KC101", "08C", 320.00,
                3, 30.0, "USD", "4532015112830366", "SILVER") + "\n");
    }
}
