
package com.ecommerce;

public class OrderController {

    public static void main(String[] args) {

        // Step 1: Create a Product object
        Product laptop = new Product(
                101, "Laptop", 850.0, 5
        );

        // Step 2: Display product information
        laptop.displayInfo();

        // Step 3: Create Facade
        CheckoutFacade checkout = new CheckoutFacade();

        // Step 4: Customer information
        String customer = "user_404";
        String address = "123 Main St";

        // Step 5: Place order using Product data
        System.out.println(
                "\nClient initiating checkout via Facade..."
        );

        boolean success = checkout.placeOrder(
                laptop.getName(),
                customer,
                address,
                laptop.getPrice()
        );

        // Step 6: Display result
        if (success) {
            System.out.println(
                    "Client received: Order completed successfully!"
            );
        } else {
            System.out.println(
                    "Client received: Order failed."
            );
        }
    }
}
